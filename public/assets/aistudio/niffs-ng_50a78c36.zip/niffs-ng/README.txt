NIFF'S_NG storefront + admin (built by ROXYC STUDIO)

- index.html is a single self-contained file (HTML, CSS, JS).
- The public storefront layout, search, filters and WhatsApp order links work in any browser.
- Products, categories, settings, image uploads and admin access use the Claude artifact runtime
  (claude.use("db"/"assets"/"user")). Outside claude.ai these are unavailable, so the shop shows its
  empty state and admin cannot save.
- Live version: https://claude.ai/artifact/BCHLTBz6CjDqR1bzzwVwga
- For standalone hosting you need a backend (e.g. Supabase with Google OAuth, RLS, storage).
